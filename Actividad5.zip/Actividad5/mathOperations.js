import fetch from "node-fetch";
const suma = (a,b) => a+b;
const resta = (a,b) => a-b;
const multiplicar = (a,b) => a*b;
const dividir = (a,b) => a/b;

export { suma,resta,multiplicar,dividir};
